﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace Lab_5
{
    public partial class IniEditor : Form
    {
        string filePath;
        Manager manager;
        public IniEditor()
        {
            InitializeComponent();
            filePath = string.Empty;
            manager = new Manager();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "C:\\Users\\Renas\\source\\repos\\Lab_5";
            openFileDialog.Filter = "ini files (*.ini)|*.ini|All files (*.*)|*.*";
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                filePath = openFileDialog.FileName;

                manager.ReadFile(filePath);

                MainPanel.Enabled = true;
            }
            setBlockList();
        }
        void setBlockList()
        {
            listOfBlocks.Items.Clear();
            listOfBlocks.DisplayMember = "name";
            foreach (var item in manager.BlockS)
            { 
               listOfBlocks.Items.Add(item);
            }
        }
        
        private void AddBlockBtn_Click(object sender, EventArgs e)
        {
            using (var form = new BlockForm())
            {
                var result = form.ShowDialog();
                if (result == DialogResult.OK)
                {
                    manager.BlockS.Add(form.output);
                    setBlockList();
                }
            }
        }

        private void DeleteBlockBtn_Click(object sender, EventArgs e)
        {
            if (listOfBlocks.SelectedIndex > -1)
            {
                manager.BlockS.Remove(manager.BlockS[listOfBlocks.SelectedIndex]);
                setBlockList();
            }
        }

        private void AddFieldBtn_Click(object sender, EventArgs e)
        {
            if (listOfBlocks.SelectedIndex > -1)
            {
                using (var form = new PropertyForm())
                {
                    var result = form.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        manager.BlockS[listOfBlocks.SelectedIndex].Properties.Add(form.output);
                        setPropertyList();
                    }
                }
            }
        }

        private void DeleteFieldBtn_Click(object sender, EventArgs e)
        {
            if (listOfProperty.SelectedIndex > -1)
            {
                manager
                            .BlockS[listOfBlocks.SelectedIndex]
                            .Properties
                            .Remove(manager
                                .BlockS[listOfBlocks.SelectedIndex]
                                .Properties[listOfProperty.SelectedIndex]
                                );
                setPropertyList();
            }
        }

        private void EditFieldBtn_Click(object sender, EventArgs e)
        {
            if (listOfProperty.SelectedIndex > -1)
            {
                Property temp = manager.BlockS[listOfBlocks.SelectedIndex].Properties[listOfProperty.SelectedIndex];
                using (var form = new PropertyForm(temp.name, temp.data))
                {
                    var result = form.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        temp.name = form.output.name;
                        temp.data = form.output.data;
                        setPropertyList();
                    }
                }
            }
        }

        private void SaveFileBtn_Click(object sender, EventArgs e)
        {
            
        }

        private void SaveFileBtn_Click_1(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(filePath))
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.InitialDirectory = "C:\\Users\\Renas\\source\\repos\\Lab_5";
                saveFileDialog.Filter = "ini files (*.ini)|*.ini|All files (*.*)|*.*";
                saveFileDialog.RestoreDirectory = true;

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    filePath = saveFileDialog.FileName;
                }
            }
            manager.SaveFile(filePath);
        }
        void setPropertyList()
        {
            listOfProperty.Items.Clear();
            if (listOfBlocks.SelectedIndex > -1)
            {
                listOfProperty.DisplayMember = "name";
                Block block = manager.BlockS[listOfBlocks.SelectedIndex];
                foreach (var item in block.Properties)
                {
                    listOfProperty.Items.Add(item);
                }
            }
            
        }
        private void listOfBlocks_SelectedIndexChanged(object sender, EventArgs e)
        {
            setPropertyList();
        }

        private void valueTX_TextChanged(object sender, EventArgs e)
        {

        }

        private void listOfProperty_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listOfBlocks.SelectedIndex > -1)
            {
                if (listOfBlocks.SelectedIndex > -1)
                {
                    valueTX.Text = manager.BlockS[listOfBlocks.SelectedIndex].Properties[listOfProperty.SelectedIndex].data;
                }
            }
            else
            {
                valueTX.Text = "";
            }
        }

        private void EditBlock_Click(object sender, EventArgs e)
        {
            if (listOfBlocks.SelectedIndex > -1)
            {
                using (var form = new BlockForm(manager.BlockS[listOfBlocks.SelectedIndex].name))
                {
                    var result = form.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        manager.BlockS[listOfBlocks.SelectedIndex].name = form.output.name;
                        setBlockList();
                    }
                }
            }
        }

        private void CreateFileBtn_Click(object sender, EventArgs e)
        {
            MainPanel.Enabled = true;
            clearAll();


        }
        void clearAll()
        {
            listOfBlocks.Items.Clear();
            listOfProperty.Items.Clear();
            valueTX.Text = "";
            manager.BlockS.Clear();
        }
        private void CloseFileBtn_Click(object sender, EventArgs e)
        {
            MainPanel.Enabled = false;
            clearAll();
        }
    }
    
    public class Manager
    {
        public List<Block> BlockS = new List<Block>();

        public void ReadFile(string filePath)
        {
            StreamReader reader = new StreamReader(filePath);
            Property property = new Property();
            while (!reader.EndOfStream)
            {
                String str = reader.ReadLine();

                if (str.Contains("[") && str.Contains("]"))
                {
                    BlockS.Add(new Block(str.Trim('[',']')));
                }
                if (str.Contains("="))
                {
                    string[] words = str.Split(new char[] { '=' });
                    BlockS[BlockS.Count-1].Properties.Add(new Property(words[0], words[1]));
                }
            }
            reader.Close();
        }
        public void SaveFile(string filePath)
        {
            StreamWriter writer = new StreamWriter(filePath);
            foreach (var block in BlockS)
            {
                writer.WriteLine('['+block.name+']');
                foreach (var property in block.Property)
                {
                    writer.WriteLine(property.name + "=" + property.data);
                }
            }
            writer.Close();
        }
    }
    public class Block
    {
        public String name { get; set; }
        public LinkedList<Property> Property { get; set; }
        public List<Property> Properties { get; set; }
        public Block(string name)
        {
            this.name = name;
            Properties = new List<Property>();
            Property = new LinkedList<Property>();
        }

        
    }
    public class Property
    {
        public Property()
        {
            this.name = "";
            this.data = "";
        }
        public Property(string name, string data)
        {
            this.name = name;
            this.data = data;
        }

        public String name { get; set; }
        public String data { get; set; }
    }
    
}
